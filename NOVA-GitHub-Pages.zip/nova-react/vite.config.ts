import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '')
  const isGitHubPages = env.GITHUB_PAGES === 'true'

  return {
    plugins: [react()],
    // GitHub Pages serves this project from /Nova.ai/, not from the domain root.
    base: isGitHubPages ? '/Nova.ai/' : './',
    server: { proxy: { '/api': 'http://localhost:8787' } },
  }
})
