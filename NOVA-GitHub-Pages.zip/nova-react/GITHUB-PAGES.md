# NOVA on GitHub Pages

GitHub Pages hosts only the static React frontend. The protected Node.js API and Qwen key must remain on Render.

## GitHub Pages deployment

1. Push this project folder to the `Nova.ai` repository (repository root must contain `package.json` and `src/`).
2. In GitHub, open **Settings → Pages → Build and deployment** and select **GitHub Actions** as the source.
3. Add a repository variable at **Settings → Secrets and variables → Actions → Variables**:
   - Name: `VITE_API_URL`
   - Value: the HTTPS base URL of the deployed Render backend, without a trailing slash (for example `https://your-service.onrender.com`).
4. Push to `main` or `master`, or run **Actions → Deploy NOVA to GitHub Pages → Run workflow**.
5. Open `https://andrey100prizma.github.io/Nova.ai/`.

The workflow builds the Vite app with the correct `/Nova.ai/` base path and publishes `dist/`. It does not expose the Qwen API key.

## Render backend configuration

Deploy the same repository to Render using `render.yaml`, then set these environment variables in the Render service:

- `FRONTEND_ORIGIN=https://andrey100prizma.github.io`
- `AI_BASE_URL` — your Qwen-compatible API endpoint
- `AI_API_KEY` — private provider key
- `NOVA_ACCESS_PASSWORD` — a unique password of at least 12 characters
- `NOVA_SESSION_SECRET` — random secret of at least 32 characters (Render Blueprint may generate it)

The backend uses credentialed CORS restricted to `FRONTEND_ORIGIN`, validates the browser Origin, and issues a Secure, HttpOnly, SameSite=None session cookie for the cross-site Pages-to-Render connection. Do not use wildcard CORS.

## Important

- `VITE_API_URL` is a public frontend setting containing only the Render URL. Never put `AI_API_KEY`, `NOVA_ACCESS_PASSWORD`, or `NOVA_SESSION_SECRET` in a `VITE_` variable.
- GitHub Pages alone cannot run login, `/api/chat`, or Node.js. Those features work only while the Render backend is deployed and configured.
- Browsers may apply third-party-cookie restrictions to cross-site cookies; this is especially relevant on iPhone Safari. If sign-in is blocked, the most reliable setup is to host both frontend and API on the same custom domain or serve the frontend from Render alongside the API.
