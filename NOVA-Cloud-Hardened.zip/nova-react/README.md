# NOVA Cloud Secure — React + TypeScript + Node.js

NOVA is a single-origin web app: the Node.js service serves the built React app and proxies authenticated chat requests to the configured Qwen-compatible API. The AI provider key stays on the server.

## Security included

- Password-protected access. The backend refuses to start unless `NOVA_ACCESS_PASSWORD` (12+ characters) and `NOVA_SESSION_SECRET` (32+ characters) are configured.
- Signed, expiring (8-hour) session cookie: `HttpOnly`, `SameSite=Strict`, and `Secure` on HTTPS. Logout clears the cookie.
- Chat API requires a valid session and same-origin `Origin` header. Login and logout also require same-origin requests. Missing Origin is rejected for state-changing API calls.
- Login attempt throttling, per-session chat throttling, global request throttling, and a cap on concurrent AI requests.
- The backend deliberately does **not** trust `X-Forwarded-For`; clients can spoof it unless the proxy chain is explicitly trusted. Behind Render, the socket peer may be the shared proxy, so add Cloudflare WAF/rate limiting for edge-level per-IP protection.
- Strict request body/message limits, allowed message roles only, server-owned system prompt, model allowlist, upstream timeout and bounded response size.
- Security headers: CSP, HSTS on HTTPS, frame denial, MIME sniffing protection, restrictive referrer and permissions policies.
- Static path traversal protection and no diagnostic/provider secrets returned to visitors.

This is defense-in-depth for a small private deployment, not a guarantee against all DDoS or infrastructure attacks. Use Cloudflare in front of the service, enable MFA on provider accounts, monitor billing, and rotate credentials if exposed. For multiple server instances, move rate limits and session revocation to shared Redis/storage.

## 1. Configure Qwen API

Create an API key in the same Alibaba Cloud Model Studio region as your endpoint. Keep the key private. Frankfurt endpoint format:

```text
https://{WorkspaceId}.eu-central-1.maas.aliyuncs.com/compatible-mode/v1
```

Set `AI_BASE_URL`, `AI_API_KEY`, `AI_MODEL`, and `AI_CODER_MODEL` as server environment variables. Never put the provider key in frontend source code or commit it to GitHub.

## 2. Required security secrets

Set these server-side environment variables before starting the app:

- `NOVA_ACCESS_PASSWORD`: a unique password of at least 12 characters. Prefer a randomly generated passphrase.
- `NOVA_SESSION_SECRET`: at least 32 random characters. Generate one with `openssl rand -base64 48`.

Example local `.env` (do not commit it):

```env
NOVA_ACCESS_PASSWORD=replace-with-a-long-unique-password
NOVA_SESSION_SECRET=replace-with-random-output-from-openssl
AI_BASE_URL=https://YOUR_WORKSPACE.eu-central-1.maas.aliyuncs.com/compatible-mode/v1
AI_API_KEY=YOUR_PRIVATE_PROVIDER_KEY
AI_MODEL=qwen3.8-flash
AI_CODER_MODEL=qwen3-coder-flash
```

The server intentionally exits at startup if either access secret is missing or too short. `.gitignore` excludes `.env` files.

## 3. Run locally

```bash
npm install
npm run build
npm start
```

Open `http://localhost:8787`, then enter `NOVA_ACCESS_PASSWORD` in the login screen.

## 4. Deploy to Render

1. Push the project contents (not the parent folder) to a private GitHub repository if you do not want the source public.
2. In Render choose **New → Blueprint** and select the repository.
3. `render.yaml` configures a Frankfurt Web Service. Set `AI_BASE_URL`, `AI_API_KEY`, and `NOVA_ACCESS_PASSWORD` in Render's environment settings. Render generates `NOVA_SESSION_SECRET` from `generateValue: true`.
4. Deploy and open the Render URL. Sign in with the password you set.
5. Visit `/api/health`; it returns only `{ "ok": true }` and does not disclose provider configuration.

Do not deploy without setting the required password. Do not share the access password or provider API key in chat or GitHub.

## 5. Environment variables

- `AI_BASE_URL`, `AI_API_KEY`: private provider endpoint and key.
- `AI_MODEL`, `AI_CODER_MODEL`: server-side model allowlist.
- `NOVA_ACCESS_PASSWORD`: required app login password (12+ chars).
- `NOVA_SESSION_SECRET`: required HMAC signing secret (32+ chars).
- `RATE_LIMIT_PER_MINUTE`: requests per signed-in session (default 20).
- `GLOBAL_RATE_LIMIT_PER_MINUTE`: process-wide request cap (default 120).
- `LOGIN_RATE_LIMIT_PER_WINDOW`: login attempts per socket peer per minute (default 8).
- `MAX_CONCURRENT_AI`: simultaneous upstream calls (default 4).
- `AI_TIMEOUT_MS`: upstream timeout (default 90000).
- `PORT`: supplied automatically by Render.

## 6. Known limitations

- In-memory rate limits reset on restart and are not shared across multiple instances. Cloudflare rate limiting/WAF should protect the public edge. Use Redis for distributed quotas.
- The socket peer address is used rather than trusting user-supplied forwarding headers. On a reverse-proxy platform this can group visitors behind the proxy for login throttling; Cloudflare should enforce per-client IP limits at the edge.
- The single shared password is suitable for a private beta, not a multi-user product. For multiple users, implement individual accounts, password hashing with a persistent user store, MFA, and session revocation.
- Chat history remains in the browser's local storage and is not synchronized across devices.
- No software can promise absolute protection from all attacks. Keep dependencies updated and monitor logs, uptime, and provider billing.
