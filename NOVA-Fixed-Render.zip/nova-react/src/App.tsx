import { useEffect, useRef, useState, type FormEvent } from 'react'
import './styles.css'

type Message = { id: number; role: 'assistant' | 'user'; text: string; time: string }
type Tab = 'chat' | 'models' | 'settings'

const starterMessages: Message[] = [
  { id: 1, role: 'assistant', text: 'Привет! Я NOVA. Выбери модель в разделе «Модели» и подключи AI-сервер, чтобы начать настоящий диалог.', time: 'Сейчас' },
]

const API_URL = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '')

async function askNova(history: Message[], text: string, model: string): Promise<string> {
  const response = await fetch(`${API_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      messages: [
        ...history.slice(-16).filter(item => item.role === 'user' || item.role === 'assistant').map(item => ({ role: item.role, content: item.text.slice(0, 8000) })),
        { role: 'user', content: text.slice(0, 8000) },
      ],
    }),
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(data.error || `Ошибка API (${response.status})`)
  return data.reply || 'Модель вернула пустой ответ.'
}

function Icon({ name }: { name: string }) {
  const paths: Record<string, string> = {
    chat: 'M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8A8.5 8.5 0 0 1 8.7 3.9a8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8z',
    grid: 'M3 3h7v7H3z M14 3h7v7h-7z M14 14h7v7h-7z M3 14h7v7H3z',
    settings: 'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-1.6 2.8-.2-.1a1.7 1.7 0 0 0-1.9.3l-.1.1h-3.2l-.1-.2a1.7 1.7 0 0 0-1.5-1l-.2.1-2.8-1.6.1-.2a1.7 1.7 0 0 0-.3-1.9l-.1-.1v-3.2l.2-.1a1.7 1.7 0 0 0 1-1.5l-.1-.2 1.6-2.8.2.1a1.7 1.7 0 0 0 1.9-.3l.1-.1h3.2l.1.2a1.7 1.7 0 0 0 1.5 1l.2-.1 2.8 1.6-.1.2a1.7 1.7 0 0 0 .3 1.9l.1.1v3.2z',
    plus: 'M12 5v14 M5 12h14', send: 'm22 2-7 20-4-9-9-4 20-7z M22 2 11 13', mic: 'M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z M19 10v2a7 7 0 0 1-14 0v-2 M12 19v3 M8 22h8',
  }
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d={paths[name] || paths.chat} /></svg>
}

export default function App() {
  const [tab, setTab] = useState<Tab>('chat')
  const [messages, setMessages] = useState<Message[]>(() => {
    try {
      const saved = localStorage.getItem('nova-chat-history')
      return saved ? JSON.parse(saved) as Message[] : starterMessages
    } catch { return starterMessages }
  })
  const [draft, setDraft] = useState('')
  const [model, setModel] = useState('qwen3.8-flash')
  const [voiceOn, setVoiceOn] = useState(false)
  const [sending, setSending] = useState(false)
  const [notice, setNotice] = useState('')
  const [authenticated, setAuthenticated] = useState(false)
  const [checkingSession, setCheckingSession] = useState(true)
  const [accessPassword, setAccessPassword] = useState('')
  const [loginError, setLoginError] = useState('')
  const [loggingIn, setLoggingIn] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let active = true
    fetch(`${API_URL}/api/session`, { credentials: 'same-origin' })
      .then(response => response.json())
      .then(data => { if (active) setAuthenticated(Boolean(data.authenticated)) })
      .catch(() => { if (active) setLoginError('Не удалось проверить защищённую сессию.') })
      .finally(() => { if (active) setCheckingSession(false) })
    return () => { active = false }
  }, [])
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])
  useEffect(() => {
    try { localStorage.setItem('nova-chat-history', JSON.stringify(messages.slice(-100))) } catch { /* storage may be unavailable */ }
  }, [messages])

  async function login(event: FormEvent) {
    event.preventDefault()
    if (loggingIn) return
    setLoggingIn(true)
    setLoginError('')
    try {
      const response = await fetch(`${API_URL}/api/login`, {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: accessPassword }),
      })
      const data = await response.json().catch(() => ({}))
      if (!response.ok) throw new Error(data.error || 'Не удалось войти.')
      setAuthenticated(true)
      setAccessPassword('')
    } catch (error) { setLoginError(error instanceof Error ? error.message : 'Ошибка входа.') }
    finally { setLoggingIn(false) }
  }

  async function logout() {
    try { await fetch(`${API_URL}/api/logout`, { method: 'POST', credentials: 'same-origin' }) }
    finally { setAuthenticated(false); setMessages(starterMessages); setTab('chat') }
  }

  async function sendMessage() {
    const text = draft.trim()
    if (!text || sending) return
    const now = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })
    const prior = messages
    setMessages(old => [...old, { id: Date.now(), role: 'user', text, time: now }])
    setDraft('')
    setSending(true)
    try {
      const reply = await askNova(prior, text, model)
      setMessages(old => [...old, { id: Date.now() + 1, role: 'assistant', text: reply, time: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) }])
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Не удалось связаться с AI-сервером.'
      setNotice(`${message}. Проверь, запущен ли backend и доступна ли модель.`)
      setMessages(old => [...old, { id: Date.now() + 1, role: 'assistant', text: `Не удалось получить ответ: ${message}`, time: new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }) }])
    } finally { setSending(false) }
  }

  function speak(text: string) {
    if (!('speechSynthesis' in window)) { setNotice('Озвучивание не поддерживается этим браузером.'); return }
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.lang = 'ru-RU'
    window.speechSynthesis.speak(utterance)
  }

  function voiceInput() {
    const SpeechRecognition = (window as Window & { SpeechRecognition?: new () => { lang: string; onresult: (event: { results: { [index: number]: { [index: number]: { transcript: string } } } }) => void; onerror: () => void; start: () => void } }).SpeechRecognition
    if (!SpeechRecognition) { setNotice('Голосовой ввод пока не поддерживается этим браузером.'); return }
    const recognition = new SpeechRecognition()
    recognition.lang = 'ru-RU'
    recognition.onresult = event => setDraft(event.results[0][0].transcript)
    recognition.onerror = () => setNotice('Не удалось распознать речь. Проверь разрешение на микрофон.')
    recognition.start()
    setNotice('Слушаю… Скажи сообщение.')
  }

  if (checkingSession) return <div className="auth-shell"><div className="auth-card"><span className="brand-mark">N</span><h1>NOVA</h1><p>Проверяем защищённую сессию…</p></div></div>
  if (!authenticated) return <div className="auth-shell"><form className="auth-card" onSubmit={login}><span className="brand-mark">N</span><span className="eyebrow">ЗАЩИЩЁННЫЙ ДОСТУП</span><h1>Вход в NOVA</h1><p>Введи пароль доступа, чтобы открыть AI-помощника.</p><label htmlFor="nova-password">Пароль</label><input id="nova-password" type="password" autoComplete="current-password" value={accessPassword} onChange={event => setAccessPassword(event.target.value)} maxLength={256} required /><button className="auth-submit" type="submit" disabled={loggingIn || !accessPassword}>{loggingIn ? 'Проверяем…' : 'Войти'}</button>{loginError && <p className="auth-error" role="alert">{loginError}</p>}<small>Сессия защищена HttpOnly cookie и автоматически истекает через 8 часов.</small></form></div>

  return <div className="app-shell">
    <header className="topbar">
      <button className="brand" onClick={() => setTab('chat')} aria-label="NOVA — на главную"><span className="brand-mark">N</span><span>NOVA<small>AI WORKSPACE</small></span></button>
      <div className="top-status"><i /> AI API</div>
      <button className="avatar" onClick={() => setTab('settings')} aria-label="Настройки">U</button>
    </header>

    <main className="main-area">
      {tab === 'chat' && <section className="chat-screen">
        <div className="chat-heading"><div><span className="eyebrow">ТВОЁ ПРОСТРАНСТВО</span><h1>Чем займёмся?</h1><p>Идеи, код и задачи — в одном месте.</p></div><button className="new-chat" onClick={() => setMessages(starterMessages)}><Icon name="plus"/> <span>Новый чат</span></button></div>
        <div className="model-pill"><span className="pulse"/><span>{model}</span><span className="pill-muted">· через защищённый API</span></div>
        <div className="messages" aria-live="polite">
          {messages.map(message => <article className={`message ${message.role}`} key={message.id}><div className="message-avatar">{message.role === 'assistant' ? 'N' : 'Я'}</div><div className="message-content"><div className="message-meta">{message.role === 'assistant' ? 'NOVA' : 'ТЫ'} <span>{message.time}</span></div><p>{message.text}</p>{message.role === 'assistant' && <button className="speak-btn" onClick={() => speak(message.text)}>↗ Озвучить</button>}</div></article>)}
          {sending && <div className="typing-indicator">NOVA печатает…</div>}<div ref={bottomRef}/>
        </div>
        <div className="composer-wrap"><div className="suggestions"><button onClick={() => setDraft('Помоги мне написать код')}>✳ Помоги с кодом</button><button onClick={() => setDraft('Придумай идеи для проекта')}>◇ Идеи для проекта</button></div><form className="composer" onSubmit={e => { e.preventDefault(); sendMessage() }}><textarea maxLength={8000} value={draft} onChange={e => setDraft(e.target.value.slice(0, 8000))} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() } }} placeholder="Напиши сообщение NOVA…" rows={1}/><button type="button" className="icon-btn" onClick={voiceInput} aria-label="Голосовой ввод"><Icon name="mic"/></button><button type="submit" className="send-btn" disabled={!draft.trim() || sending} aria-label="Отправить"><Icon name="send"/></button></form><div className="disclaimer">Ответы генерируются подключённой моделью через твой backend</div></div>
      </section>}

      {tab === 'models' && <section className="content-screen"><span className="eyebrow">ИНТЕЛЛЕКТ</span><h1>Модели</h1><p className="screen-lead">Выбери модель, настроенную на сервере NOVA.</p><div className="model-list"><button className={`model-card ${model === 'qwen3.8-flash' ? 'selected' : ''}`} onClick={() => { setModel('qwen3.8-flash'); setNotice('Выбрана Qwen 3.8 Flash.') }}><span className="model-symbol">⌘</span><span><b>Qwen 3.8 Flash</b><small>Универсальная облачная модель</small></span><span className="model-tag">ВЫБРАТЬ</span></button><button className={`model-card ${model === 'qwen3-coder-flash' ? 'selected' : ''}`} onClick={() => { setModel('qwen3-coder-flash'); setNotice('Выбрана Qwen 3 Coder Flash.') }}><span className="model-symbol">⌘</span><span><b>Qwen 3 Coder Flash</b><small>Облачная модель для программирования</small></span><span className="model-tag">ВЫБРАТЬ</span></button></div><div className="info-panel"><b>Как устроено подключение</b><p>Сайт отправляет сообщения на облачный backend NOVA. Backend обращается к Qwen через официальный API. Секретный ключ хранится только на сервере, а не в браузере.</p></div></section>}

      {tab === 'settings' && <section className="content-screen"><span className="eyebrow">ПЕРСОНАЛИЗАЦИЯ</span><h1>Настройки</h1><p className="screen-lead">Управление интерфейсом NOVA.</p><div className="settings-group"><div className="setting-row"><span><b>Текущий режим</b><small>Выбранная модель</small></span><strong>{model}</strong></div><div className="setting-row"><span><b>Озвучивание ответов</b><small>Через голосовые функции браузера</small></span><button className={`toggle ${voiceOn ? 'on' : ''}`} onClick={() => setVoiceOn(v => !v)} aria-label="Переключить озвучивание"><i/></button></div><div className="setting-row"><span><b>Защищённый доступ</b><small>Завершить текущую сессию</small></span><button className="text-action" onClick={logout}>Выйти</button></div><div className="setting-row"><span><b>История чата</b><small>Сохраняется в браузере на этом устройстве</small></span><button className="text-action" onClick={() => { setMessages(starterMessages); setNotice('История текущего чата очищена.') }}>Очистить</button></div></div><div className="info-panel"><b>NOVA · версия 0.2</b><p>Мобильный интерфейс на React и TypeScript. Адаптирован для смартфонов и больших экранов.</p></div></section>}
    </main>

    <nav className="bottom-nav" aria-label="Основная навигация"><button className={tab === 'chat' ? 'active' : ''} onClick={() => setTab('chat')}><Icon name="chat"/><span>Чат</span></button><button className={tab === 'models' ? 'active' : ''} onClick={() => setTab('models')}><Icon name="grid"/><span>Модели</span></button><button className={tab === 'settings' ? 'active' : ''} onClick={() => setTab('settings')}><Icon name="settings"/><span>Настройки</span></button></nav>
    {notice && <button className="toast" onClick={() => setNotice('')}>{notice}<span> ×</span></button>}
  </div>
}
