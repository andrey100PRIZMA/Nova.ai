import Orb from '../components/Orb'
import SectionTitle from '../components/SectionTitle'

const features = [
  ['⌘', 'Помощь с кодом', 'Объяснение кода, поиск ошибок и помощь с проектами.'],
  ['◉', 'Голосовой режим', 'Общение голосом и озвучивание ответов.'],
  ['▤', 'Работа с файлами', 'Создание и изменение файлов с контролем каждого действия.'],
  ['⌁', 'История диалогов', 'Сохранение переписки и быстрый возврат к задачам.'],
  ['◇', 'Выбор модели', 'Переключение между моделями для общения и программирования.'],
  ['↗', 'GitHub', 'Помощь с Git и публикацией проектов после подтверждения.'],
]

export default function Home() {
  return <main id="top">
    <div className="wrap hero">
      <div className="hero-copy">
        <span className="eyebrow">NOVA <span className="eyebrow-divider">/</span> твой AI-помощник</span>
        <h1>Меньше рутины.<br /><span className="grad">Больше идей.</span></h1>
        <p className="lead">Помощник для общения, программирования и собственных проектов. Сначала удобный мобильный сайт, затем отдельное приложение для Windows.</p>
        <div className="actions"><a className="btn" href="#features">Изучить NOVA <span aria-hidden="true">↗</span></a><a className="btn ghost" href="#roadmap">Что дальше</a></div>
        <div className="hero-note"><span className="status-dot" /> <span>Сайт-презентация · разработка продолжается</span></div>
      </div>
      <div className="hero-visual"><Orb /><div className="floating-chip chip-top"><span className="chip-icon">✳</span><span><b>Твои идеи</b><small>От мысли к результату</small></span></div><div className="floating-chip chip-bottom"><span className="chip-icon">⌘</span><span><b>Твои проекты</b><small>Код · задачи · творчество</small></span></div></div>
      <a className="scroll-cue" href="#features"><span /> Листай вниз</a>
    </div>

    <section id="features"><div className="wrap">
      <SectionTitle kicker="Возможности" title="Один помощник. Много задач." description="NOVA развивается как единое пространство для идей, общения и работы. Эти функции — план, а не обещание уже готовых инструментов." />
      <div className="grid">{features.map(([icon, title, body], i) => <article className="card" key={title}><div className="card-top"><div className="ico">{icon}</div><span className="card-index">0{i + 1}</span></div><h3>{title}</h3><p>{body}</p><span className="card-arrow" aria-hidden="true">↗</span></article>)}</div>
    </div></section>

    <section id="models"><div className="wrap">
      <SectionTitle kicker="Локальный интеллект" title="Технологии под твоим контролем" description="В дальнейшем планируем добавить локальные модели для Windows. Это позволит выполнять часть задач прямо на устройстве без оплаты за каждый запрос." />
      <div className="models">
        <article className="model"><div className="model-head"><span className="model-icon">⌘</span><span className="tag">План · код</span></div><h3>Qwen Coder 3B</h3><p>Компактная модель для генерации, анализа и объяснения программного кода. Скорость зависит от компьютера.</p></article>
        <article className="model"><div className="model-head"><span className="model-icon">✳</span><span className="tag">План · повседневные задачи</span></div><h3>Лёгкая Qwen</h3><p>Модель для обычных вопросов, идей и текстов. Для локального запуска понадобятся память и место на устройстве.</p></article>
      </div>
      <p className="fineprint">Модели указаны как предварительный выбор. Сейчас они не подключены к сайту.</p>
    </div></section>

    <section id="roadmap"><div className="wrap">
      <SectionTitle kicker="Дорожная карта" title="Сначала мобильная версия" description="Делаем поэтапно, чтобы каждая версия была удобной и проверенной на реальных устройствах." />
      <div className="steps">
        <article className="step step-current"><div className="step-top"><span className="num">ЭТАП 01</span><span className="step-state">Сейчас</span></div><h3>Мобильный сайт</h3><p>Адаптация интерфейса для iPhone и Android, удобная навигация и проверка экранов.</p></article>
        <article className="step"><div className="step-top"><span className="num">ЭТАП 02</span><span className="step-state planned">Далее</span></div><h3>Версия для ПК</h3><p>Отдельная компоновка для больших экранов и удобная работа с клавиатурой и мышью.</p></article>
        <article className="step"><div className="step-top"><span className="num">ЭТАП 03</span><span className="step-state planned">Потом</span></div><h3>NOVA для Windows</h3><p>Локальная модель, работа с файлами и инструменты разработки с подтверждением действий.</p></article>
      </div>
      <div className="notice"><span className="notice-mark">i</span><div><strong>Важно: ИИ и Windows-приложение ещё не выпущены</strong><p>Сейчас создаётся мобильная версия сайта. Кнопок на несуществующие загрузки не будет.</p></div></div>
    </div></section>

    <section id="faq"><div className="wrap faq-layout">
      <div><SectionTitle kicker="FAQ" title="Частые вопросы" description="Коротко и честно о текущем состоянии проекта." /></div>
      <div className="faq">
        <details><summary>NOVA уже работает как настоящий ИИ?</summary><p>Пока нет. Сейчас это сайт-презентация. Подключение модели — отдельный этап разработки.</p></details>
        <details><summary>Сайт будет работать на iPhone и Android?</summary><p>Да. Мобильная версия создаётся как адаптивный сайт, который открывается в браузере на телефоне.</p></details>
        <details><summary>Будет ли отдельная версия для компьютера?</summary><p>Да. После мобильной версии подготовим отдельную компоновку для ПК, а затем займёмся Windows-приложением.</p></details>
        <details><summary>Когда появится Windows-приложение?</summary><p>Точная дата пока не назначена. Сначала нужно закончить и проверить сайт, затем разработать приложение.</p></details>
      </div>
    </div></section>
    <section className="closing"><div className="wrap closing-inner"><span className="closing-mark">N</span><p>Идеи заслуживают большего.</p><a className="btn" href="#top">Наверх ↑</a></div></section>
  </main>
}
