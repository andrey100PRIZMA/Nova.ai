type Props = { kicker: string; title: string; description?: string }
export default function SectionTitle({ kicker, title, description }: Props) {
  return <><div className="kicker">{kicker}</div><h2 className="heading">{title}</h2>{description && <p className="desc">{description}</p>}</>
}
