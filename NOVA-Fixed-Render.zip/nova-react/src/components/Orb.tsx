export default function Orb() {
  return <div className="visual" aria-hidden="true">
    <div className="orb" />
    <div className="bubble b1"><strong>Помощник по коду</strong>Идеи → проекты</div>
    <div className="bubble b2"><strong>Голосовой режим</strong>Общение без клавиатуры</div>
  </div>
}
