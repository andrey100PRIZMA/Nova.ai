import { useEffect, useState } from 'react'

const links = [
  ['#features', 'Возможности'],
  ['#models', 'Модели'],
  ['#windows', 'Windows'],
  ['#faq', 'Вопросы'],
]

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenuOpen(false)
    }
    window.addEventListener('keydown', closeOnEscape)
    return () => window.removeEventListener('keydown', closeOnEscape)
  }, [])

  useEffect(() => {
    document.body.classList.toggle('menu-is-open', menuOpen)
    return () => document.body.classList.remove('menu-is-open')
  }, [menuOpen])

  return <header className="site-header">
    <div className="wrap nav">
      <a className="brand" href="#top" aria-label="NOVA — наверх" onClick={() => setMenuOpen(false)}>
        <span className="logo">N</span><span>NOVA</span>
      </a>
      <nav id="mobile-navigation" className={`links${menuOpen ? ' links-open' : ''}`} aria-label="Основная навигация">
        {links.map(([href, label]) => <a key={href} href={href} onClick={() => setMenuOpen(false)}>{label}<span aria-hidden="true">↗</span></a>)}
      </nav>
      <a className="btn nav-cta" href="#windows">О проекте <span aria-hidden="true">↗</span></a>
      <button className="menu-toggle" type="button" aria-label={menuOpen ? 'Закрыть меню' : 'Открыть меню'} aria-expanded={menuOpen} aria-controls="mobile-navigation" onClick={() => setMenuOpen(open => !open)}>
        <span className={`menu-lines${menuOpen ? ' is-open' : ''}`} aria-hidden="true"><i /><i /></span>
      </button>
    </div>
    {menuOpen && <button className="menu-backdrop" aria-label="Закрыть меню" onClick={() => setMenuOpen(false)} />}
  </header>
}
